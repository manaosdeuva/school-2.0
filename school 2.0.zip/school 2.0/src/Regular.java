public class Regular extends Alumno {

	public Regular(int legajo, String nombre, double promedio) {
		super(legajo, nombre, promedio);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getPorcentaje() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String toString() {
		return String.format("legajo: %s, nombre: %s, promedio: %s", getLegajo(), getNombre(), getPromedio());
	}

}
