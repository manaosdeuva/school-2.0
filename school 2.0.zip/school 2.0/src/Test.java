import java.util.LinkedList;

public class Test {

	public static void main(String[] args) throws Exception {
		pija();
		try {
			// aux(new Escuela());

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	Estado aceptada = Estado.aceptada;
	static Estado ingresada = Estado.ingresada;
	Estado rechazada = Estado.rechazada;

	protected static Carrera[] carrera() throws Exception {
		String[] nom = carreras();
		Carrera[] ca = new Carrera[15];
		// System.out.println(nom.length);
		for (int i = 0; i < ca.length; i++) {
			ca[i] = new Carrera(i, nom[i]);
		}
		return ca;
	}

	protected static void pija() throws Exception {
		Escuela e = new Escuela();
		Alumno[] alumnos = alumnos();
		Carrera[] ca = carrera();
		Materia[] materias = materias();
		e.setCarreras(ca);
		e.setMaterias(materias);
		agregarCursos(e);
		agregars(e, alumnos);
		mostrarm(e.getMaterias());
		System.out.println("--____--");
		mostrarc(e.getCarreras());
		System.out.println("--____--");
		System.out.println(e.eliminarCurso("3"));
		System.out.println("--____--");
		e.informarTot();
		System.out.println("--____--");
		mostrarcu(e);
		System.out.println("--____--");
		mostrars(e);
	}

	protected static void mostrars(Escuela e) {
		for (Solicitud s : e.getSolicitudes()) {
			System.out.println(s);
		}
	}

	protected static void mostrarcu(Escuela e) {
		for (Curso c : e.getCursos()) {
			System.out.println(c);
		}
		for (Alumno a : e.popCurso().getAlu()) {
			System.out.println(a);
		}
	}

	protected static void agregarCursos(Escuela e) throws Exception {
		Curso f = null;
		int i = 0;
		Materia[] m = materias();
		for (Curso cu : cursos()) {
			for (Alumno a : alumnos()) {
				cu.add(a);
			}
			e.addCurso(cu);
		}
		// TODO cambiar id de materias
		Curso[] cursous = { crear(1), crear(2), crear(3), crear(4), crear(5), crear(6) };
		for (Curso curso : cursous) {
			curso.setId(curso.getId() + "f");
			e.addCurso(curso);
		}
	}

	protected static Curso[] cursos() throws Exception {
		Materia[] m = materias();
		Curso[] cursos = { crear(1), crear(2), crear(3), crear(4), crear(5), crear(6) };
		return cursos;
	}

	protected static Curso crear(int id) throws Exception {
		Curso c = new Curso("" + id, 0, materias()[id].getId(), id);
		return c;
	}

	protected static Alumno[] alumnos() {
		Alumno[] alumnos = { new Regular(0, "Gabriel", 6), new Becado(1, "Andres", 7, 99, 'a'),
				new Regular(2, "Ioel", 5), new Regular(3, "Pablo", 5.7), new Regular(4, "Matias", 8.5),
				new Regular(5, "Jose", 8), new Regular(6, "Raul", 9),new Regular(7,"perdedor",0) };
		return alumnos;

	}

	protected static void mostrarc(Carrera[] ca) {
		for (Carrera carrera : ca) {
			System.out.println(carrera);
		}
	}

	protected static void agregars(Escuela e, Alumno[] a) throws Exception {
		e.addSolicitud(new Solicitud(1, 1, ingresada, materias()[1].getId(), new Regular(0, "gabriel", 6)));
		e.addSolicitud(new Solicitud(2, 2, ingresada, materias()[2].getId(), new Regular(0, "gabriel", 6)));
		e.addSolicitud(new Solicitud(3, 3, ingresada, materias()[3].getId(), new Regular(0, "gabriel", 6)));
		e.addSolicitud(new Solicitud(4, 4, ingresada, materias()[4].getId(), new Regular(0, "gabriel", 6)));
		e.addSolicitud(new Solicitud(5, 5, ingresada, materias()[5].getId(), new Regular(0, "gabriel", 6)));
	}

	protected static void mostrarm(Materia[] materias) {
		for (Materia m : materias) {
			System.out.println(m);
		}
	}

	protected static String[] carreras() {
		String[] nom = { "analista", "biotecnologia", "productor musical", "dise�o digital", "dise�o industrial",
				"videojuegos", "programador", "testing", "base de datos", "dise�o web", "dise�o grafico", "animaci�n",
				"computaci�n cientifica", "radiologia", "hardware" };
		return nom;
	}

	protected static Materia[] materias() throws Exception {
		Materia[] materias = { new Materia("organizacion empresarial", 2),
				new Materia("introduccion a la informatica", 2), new Materia("fundamentos de programacion", 6),
				new Materia("taller de herramientas de programacion", 6), new Materia("matematica", 4),
				new Materia("ingles tecnico", 2), new Materia("taller de creatividad e innovacion", 2),
				new Materia("sistemas administrativos", 2), new Materia("arquitectura y sistemas operativos", 2),
				new Materia("programacion1", 6), new Materia("taller de programacion1", 6),
				new Materia("programacion en nuevas tecnologias1", 6), new Materia("base de datos1", 2),
				new Materia("analisis y metodologia de sistemas", 4), new Materia("base de datos2", 2),
				new Materia("programacion2", 6), new Materia("taller de programacion2", 6),
				new Materia("programacion en nuevas tecnologias2", 6), new Materia("programacion3", 6),
				new Materia("taller de programacion3", 6), new Materia("proyecto final", 6),
				new Materia("seguridad e integridad de sistemas", 2), new Materia("calidad de software", 2),
				new Materia("estudios judaicos", 2) };
		return materias;
	}

	public static void aux(Escuela e) throws Exception {
		Alumno alumno = new Regular(0, "Gabriel", 6);
		Alumno becado = new Becado(1, "Andres", 7, 99, 'a');
		Carrera carrera = new Carrera(0, "analista");
		Curso curso = new Curso("12e", 14, "progra", 0);
		Materia materia = new Materia("progra", "programacion", 4);
		Solicitud solicitud = new Solicitud(2, 0, Estado.ingresada, "progra", alumno);
		System.out.println(String.format("alumno %s\nbecado %s\ncarrera %s\ncurso %s\nmateria %s\nsolicitud %s", alumno,
				becado, carrera, curso, materia, solicitud));
		// Regular(int legajo,String nombre,promedio)
		// Becado(int legajo,String nombre, promedio,int porcentaje, tipo)
		// Carrera(int id,String nombre)
		// Curso(id ,int cupo ,String materia ,int carrera)
		// Materia(String id ,String nombre ,int horas )
		// Solicitud(int id ,int carrera ,Estado state ,String materia ,Alumno alu )
		/*
		 * System.out.println("niggas" +
		 * e.chequearSolicitud(e.getSolicitudes().peek()));
		 * 
		 * System.out.println(e.buscarCurso("2")); e.eliminarCurso("1");
		 * 
		 * LinkedList z = e.getCursos(); while (!z.isEmpty()) {
		 * System.out.println(z.pop()); } z = e.getSolicitudes();
		 * System.out.println(""); while (!z.isEmpty()) {
		 * System.out.println(((Solicitud) z.pop()));}
		 */

	}

}
